// Set today's date as default
document.getElementById('deliveryDate').valueAsDate = new Date();

// Load history on startup
loadHistory();

function calculateTrial() {
    const deliveryInput = document.getElementById('deliveryDate');
    const extensionDays = parseInt(document.getElementById('extensionDays').value) || 0;
    
    if (!deliveryInput.value) {
        alert('Please enter a delivery date (when the trial period starts)');
        return;
    }

    // Parse date correctly to avoid timezone issues
    const [year, month, day] = deliveryInput.value.split('-').map(num => parseInt(num));
    const deliveryDate = new Date(year, month - 1, day); // month is 0-indexed
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset time for accurate day comparison
    const baseTrialDays = 120;
    const totalTrialDays = baseTrialDays + extensionDays;

    // Calculate end date (120 days + extension from delivery)
    const endDate = new Date(deliveryDate);
    endDate.setDate(endDate.getDate() + totalTrialDays);

    // Calculate days passed and remaining
    const daysPassed = Math.floor((today - deliveryDate) / (1000 * 60 * 60 * 24));
    const daysRemaining = Math.max(0, totalTrialDays - daysPassed);
    const progressPercent = Math.min(100, (daysPassed / totalTrialDays) * 100);

    // Determine status
    let status, statusClass, tips;
    
    if (daysRemaining === 0) {
        status = 'EXPIRED';
        statusClass = 'expired';
        tips = {
            title: 'Trial Expired - Action Required',
            items: [
                'Trial period has ended',
                'Contact customer immediately',
                'Arrange return pickup if needed',
                'Process any pending returns',
                extensionDays > 0 ? `Extension of ${extensionDays} days was applied` : ''
            ].filter(Boolean)
        };
    } else if (daysRemaining <= 7) {
        status = 'ENDING SOON';
        statusClass = 'warning';
        tips = {
            title: 'Trial Ending Soon',
            items: [
                `Trial expires in ${daysRemaining} days`,
                'Send reminder email to customer',
                'Offer assistance with decision',
                'Prepare return logistics if needed',
                extensionDays > 0 ? `Extension granted: ${extensionDays} extra days` : ''
            ].filter(Boolean)
        };
    } else if (daysRemaining <= 14) {
        status = 'ACTIVE';
        statusClass = 'warning';
        tips = {
            title: 'Mid-Trial Check-in',
            items: [
                `${daysRemaining} days remaining`,
                'Consider sending satisfaction survey',
                'Offer product support if needed',
                'Remind about return policy',
                extensionDays > 0 ? `Note: ${extensionDays} extra days granted` : ''
            ].filter(Boolean)
        };
    } else {
        status = 'ACTIVE';
        statusClass = 'active';
        tips = {
            title: 'Trial Going Well',
            items: [
                `${daysRemaining} days remaining`,
                'No immediate action required',
                'Customer has plenty of time',
                'Monitor for any support requests',
                extensionDays > 0 ? `Extension: +${extensionDays} days` : ''
            ].filter(Boolean)
        };
    }

    // Store current calculation
    window.currentCalculation = {
        deliveryDate,
        extensionDays,
        daysRemaining,
        daysPassed,
        endDate,
        totalTrialDays,
        baseTrialDays,
        status,
        calculatedAt: new Date()
    };

    // Update display
    updateResults({
        daysRemaining,
        daysPassed,
        startDate: deliveryDate,
        endDate,
        progressPercent,
        status,
        statusClass,
        tips,
        extensionDays,
        totalTrialDays,
        baseTrialDays
    });

    // Show results
    document.getElementById('results').classList.add('show');
}

function updateResults(data) {
    const {
        daysRemaining, daysPassed, startDate, endDate,
        progressPercent, status, statusClass, tips,
        extensionDays, totalTrialDays, baseTrialDays
    } = data;

    // Update main result card
    const resultCard = document.getElementById('mainResult');
    resultCard.className = `result-card ${statusClass}`;

    // Update title based on status
    const titleEl = document.getElementById('resultTitle');
    if (statusClass === 'expired') {
        titleEl.textContent = 'Trial Expired';
    } else {
        titleEl.textContent = 'Days Remaining';
    }

    // Update values
    document.getElementById('resultValue').textContent = daysRemaining;
    document.getElementById('resultValue').className = `result-value ${statusClass}`;
    
    // Show extension info if applicable
    const extensionInfo = document.getElementById('extensionInfo');
    if (extensionDays > 0) {
        extensionInfo.textContent = `Extended by ${extensionDays} days (Total: ${totalTrialDays} days)`;
    } else {
        extensionInfo.textContent = '';
    }
    
    document.getElementById('startDate').textContent = formatDate(startDate);
    document.getElementById('endDate').textContent = formatDate(endDate);
    document.getElementById('daysUsed').textContent = daysPassed;
    document.getElementById('trialStatus').textContent = status;
    document.getElementById('progressPercent').textContent = Math.round(progressPercent) + '%';

    // Update progress bar
    const progressFill = document.getElementById('progressFill');
    progressFill.style.width = progressPercent + '%';
    progressFill.className = `progress-fill ${statusClass}`;
}

function formatDate(date) {
    return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    });
}

function copyNotes() {
    const calc = window.currentCalculation;
    if (!calc) {
        alert('Please calculate trial status first');
        return;
    }

    const notes = `
TRIAL PERIOD INFORMATION
═══════════════════════════════

TRIAL PERIOD
────────────
• Delivery Date (Trial Start): ${formatDate(calc.deliveryDate)}
• Trial End Date: ${formatDate(calc.endDate)}
• Base Trial Period: ${calc.baseTrialDays} days
${calc.extensionDays > 0 ? `• Extension: +${calc.extensionDays} days` : ''}
• Total Trial Period: ${calc.totalTrialDays} days

CURRENT STATUS
────────────
• Days Elapsed: ${calc.daysPassed}
• Days Remaining: ${calc.daysRemaining}
• Status: ${calc.status}
• Calculated: ${formatDate(calc.calculatedAt)} at ${calc.calculatedAt.toLocaleTimeString()}

────────────────────────────────
Generated by 120-Day Trial Calculator
    `.trim();

    navigator.clipboard.writeText(notes).then(() => {
        alert('Notes copied to clipboard!');
    }).catch(() => {
        alert('Failed to copy notes');
    });
}

function saveToHistory() {
    const calc = window.currentCalculation;
    if (!calc) {
        alert('Please calculate trial status first');
        return;
    }

    // Get existing history
    let history = JSON.parse(localStorage.getItem('trialHistory') || '[]');
    
    // Add new calculation
    history.unshift({
        id: Date.now(),
        deliveryDate: calc.deliveryDate.toISOString(),
        daysRemaining: calc.daysRemaining,
        status: calc.status,
        extensionDays: calc.extensionDays,
        calculatedAt: calc.calculatedAt.toISOString()
    });
    
    // Keep only last 20 calculations
    history = history.slice(0, 20);
    
    // Save to localStorage
    localStorage.setItem('trialHistory', JSON.stringify(history));
    
    loadHistory();
    alert('Saved to history!');
}

function loadHistory() {
    const history = JSON.parse(localStorage.getItem('trialHistory') || '[]');
    const historySection = document.getElementById('historySection');
    const historyList = document.getElementById('historyList');
    
    if (history.length === 0) {
        historySection.style.display = 'none';
        return;
    }
    
    historySection.style.display = 'block';
    historyList.innerHTML = history.map(item => `
        <div class="history-item" onclick='loadFromHistory(${JSON.stringify(item)})'>
            <div class="history-name">${formatDate(new Date(item.deliveryDate))}</div>
            <div class="history-date">
                ${item.daysRemaining} days left • 
                ${item.status}
                ${item.extensionDays > 0 ? ` (+${item.extensionDays} ext)` : ''}
            </div>
        </div>
    `).join('');
}

function loadFromHistory(item) {
    document.getElementById('deliveryDate').value = new Date(item.deliveryDate).toISOString().split('T')[0];
    document.getElementById('extensionDays').value = item.extensionDays || 0;
    
    calculateTrial();
}

function clearHistory() {
    if (confirm('Are you sure you want to clear all history?')) {
        localStorage.removeItem('trialHistory');
        loadHistory();
        alert('History cleared!');
    }
}

function exportData() {
    const calc = window.currentCalculation;
    if (!calc) {
        alert('Please calculate trial status first');
        return;
    }

    const data = {
        deliveryDate: formatDate(calc.deliveryDate),
        trialEndDate: formatDate(calc.endDate),
        baseTrialDays: calc.baseTrialDays,
        extensionDays: calc.extensionDays,
        totalTrialDays: calc.totalTrialDays,
        daysElapsed: calc.daysPassed,
        daysRemaining: calc.daysRemaining,
        status: calc.status,
        calculatedAt: calc.calculatedAt.toISOString()
    };

    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `trial-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

function resetForm() {
    document.getElementById('deliveryDate').valueAsDate = new Date();
    document.getElementById('extensionDays').value = '0';
    document.getElementById('results').classList.remove('show');
}

// Auto-calculate when delivery date changes
document.getElementById('deliveryDate').addEventListener('change', function() {
    if (this.value) {
        calculateTrial();
    }
});

// Auto-calculate when extension days change
document.getElementById('extensionDays').addEventListener('change', function() {
    if (document.getElementById('deliveryDate').value) {
        calculateTrial();
    }
});
